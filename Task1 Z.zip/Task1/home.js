var video=$("#video")
$(document).ready(function () {
    $("video").on('canplay',function () {
        $("video").mousenter(function () {
            $(this).get(0).play();
            
        })
        
    })
    
})

